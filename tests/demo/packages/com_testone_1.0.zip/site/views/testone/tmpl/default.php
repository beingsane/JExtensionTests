<?php
/**
 * @package    TestOne
 * @subpackage Views
 * @author     Nikolai Plath {@link https://github.com/elkuku}
 * @author     Created on 17-Jul-2012
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');


?>

<h1><?php echo $this->greeting; ?></h1>
