<?php
/**
 * @package    TestOne
 * @subpackage Base
 * @author     Nikolai Plath {@link https://github.com/elkuku}
 * @author     Created on 17-Jul-2012
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');


?>
<h1>I am just a dummy :~|</h1>

<p>
    Please visit the <a href="../index.php?option=com_testone">frontpage view of TestOne</a>.
</p>
