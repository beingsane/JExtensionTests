<?php
/**
 * @package    TestOne
 * @subpackage Base
 * @author     Nikolai Plath {@link https://github.com/elkuku}
 * @author     Created on 17-Jul-2012
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');


jimport('joomla.application.component.controller');

/**
 * TestOne Controller.
 *
 * @package    TestOne
 * @subpackage Controllers
 */
class TestOneController extends JController
{
}//class
